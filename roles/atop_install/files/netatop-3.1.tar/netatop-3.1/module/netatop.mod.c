#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xf8cdd757, "module_layout" },
	{ 0x61704c0d, "single_release" },
	{ 0x98600ced, "seq_read" },
	{ 0x525a244e, "seq_lseek" },
	{ 0x4864a9b0, "remove_proc_entry" },
	{ 0x934e155b, "unregister_pernet_subsys" },
	{ 0x3e18c761, "kthread_stop" },
	{ 0x47b84d71, "kmem_cache_destroy" },
	{ 0x718c5c41, "nf_unregister_sockopt" },
	{ 0xc00d5473, "wake_up_process" },
	{ 0x8c8efac3, "proc_create" },
	{ 0xa586b2f9, "register_pernet_subsys" },
	{ 0xdc1e5ca7, "kthread_create_on_node" },
	{ 0xe98a034b, "nf_register_sockopt" },
	{ 0xef464c28, "getboottime64" },
	{ 0x88833fb1, "kmem_cache_create" },
	{ 0xad27f361, "__warn_printk" },
	{ 0x27e1a049, "printk" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0x362ef408, "_copy_from_user" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0x1000e51, "schedule" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0xa1c76e0a, "_cond_resched" },
	{ 0xc6cbbc89, "capable" },
	{ 0x4629334c, "__preempt_count" },
	{ 0xb3f7646e, "kthread_should_stop" },
	{ 0x54496b4, "schedule_timeout_interruptible" },
	{ 0xa6093a32, "mutex_unlock" },
	{ 0x42b721e9, "find_vpid" },
	{ 0x41aed6e7, "mutex_lock" },
	{ 0xdb7305a1, "__stack_chk_fail" },
	{ 0x5b020cda, "nf_register_net_hooks" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0xfb2557c2, "kmem_cache_free" },
	{ 0x9166fada, "strncpy" },
	{ 0x9202ba1c, "current_task" },
	{ 0x3812050a, "_raw_spin_unlock_irqrestore" },
	{ 0x51760917, "_raw_spin_lock_irqsave" },
	{ 0xf159fe55, "kmem_cache_alloc" },
	{ 0x55e77e8, "jiffies_64" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x2aebe4e7, "nf_unregister_net_hooks" },
	{ 0x420ecfe3, "seq_printf" },
	{ 0x46a5e192, "single_open" },
	{ 0xbdfb6dbb, "__fentry__" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "5708DB468E853916D76980B");
MODULE_INFO(rhelversion, "8.2");
